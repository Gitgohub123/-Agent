import re
from typing import List, Dict

class ParserAgent:
    def parse(self, file_path: str) -> List[Dict]:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        # 简单解析: 匹配 REQ-XXX: 标题
        pattern = r'## (REQ-\d+): (.+?)\n- 描述：(.+?)\n- 合规要求：(.+?)(?=\n## |\Z)'
        matches = re.findall(pattern, content, re.DOTALL)
        
        requirements = []
        for req_id, title, desc, compliance in matches:
            requirements.append({
                "id": req_id,
                "title": title.strip(),
                "description": desc.strip(),
                "compliance": compliance.strip()
            })
        return requirements

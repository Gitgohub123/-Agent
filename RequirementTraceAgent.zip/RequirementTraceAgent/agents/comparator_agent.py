from typing import List, Dict, Tuple
import re

class ComparatorAgent:
    def compare(self, requirements: List[Dict], features: List[Dict], compliance_rules: Dict) -> Tuple[Dict, List[Dict]]:
        # 长链推理步骤:
        # 1. 语义匹配需求与代码功能点 (关键词+正则)
        # 2. 检查合规违犯 (关键字扫描 + 缺失模式检测)
        # 3. 构建覆盖率矩阵
        
        coverage = {req["id"]: {"covered": False, "matching_features": [], "reason": ""} for req in requirements}
        violations = []
        
        for req in requirements:
            # 简单规则: 需求关键词匹配功能名/代码文本
            keywords = re.findall(r'\w+', req["description"] + " " + req["title"])
            matched = []
            for feat in features:
                text_to_search = (feat["name"] + " " + feat["code"]).lower()
                for kw in keywords:
                    if kw.lower() in text_to_search and len(kw) > 2:
                        matched.append(feat["name"])
                        break
            if matched:
                coverage[req["id"]]["covered"] = True
                coverage[req["id"]]["matching_features"] = matched
                coverage[req["id"]]["reason"] = f"匹配到功能: {', '.join(matched)}"
            else:
                coverage[req["id"]]["reason"] = "未找到相关代码实现"
            
            # 合规检查 (长链: 结合代码上下文判断)
            for feat in features:
                combined_code = feat["code"].lower()
                # 检查禁止关键字
                for forbidden in compliance_rules.get("forbidden_keywords", []):
                    if forbidden.lower() in combined_code:
                        violations.append({
                            "req_id": req["id"],
                            "type": "forbidden_keyword",
                            "keyword": forbidden,
                            "file": feat["file"],
                            "function": feat["name"],
                            "detail": f"在 {feat['name']} 中发现禁止词汇: {forbidden}"
                        })
                # 检查必需模式缺失
                for required in compliance_rules.get("required_patterns", []):
                    if required.lower() not in combined_code:
                        # 但不是所有需求都需要，简单示例: 如果需求包含"审计日志"关键字，则检查
                        if "审计" in req["description"] or "audit" in req["description"].lower():
                            violations.append({
                                "req_id": req["id"],
                                "type": "missing_pattern",
                                "pattern": required,
                                "file": feat["file"],
                                "function": feat["name"],
                                "detail": f"需求要求有 {required}，但在 {feat['name']} 中未找到"
                            })
        return coverage, violations

from typing import Dict, List

class ReporterAgent:
    def generate_report(self, coverage: Dict, violations: List[Dict], output_file: str):
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("# 需求追踪与合规检查报告\n\n")
            f.write("## 1. 需求覆盖率\n\n")
            f.write("| 需求ID | 覆盖状态 | 匹配功能点 | 原因 |\n")
            f.write("|--------|----------|------------|------|\n")
            for req_id, info in coverage.items():
                status = "✅ 已覆盖" if info["covered"] else "❌ 未覆盖"
                features = ", ".join(info["matching_features"]) if info["matching_features"] else "-"
                f.write(f"| {req_id} | {status} | {features} | {info['reason']} |\n")
            
            f.write("\n## 2. 合规违犯项\n\n")
            if not violations:
                f.write("✅ 未发现合规违犯。\n")
            else:
                for v in violations:
                    f.write(f"- **{v['req_id']}** - {v['type']}: {v['detail']}\n")
                    f.write(f"  - 位置: {v['file']} -> {v['function']}\n")
            f.write("\n## 3. 建议修复动作\n\n")
            for v in violations:
                if v['type'] == 'forbidden_keyword':
                    f.write(f"- 删除或替换 `{v['keyword']}` 相关逻辑（{v['file']}）\n")
                elif v['type'] == 'missing_pattern':
                    f.write(f"- 在 {v['file']} 中添加 {v['pattern']} 实现\n")
    
    def create_jira_tasks(self, violations: List[Dict], dry_run=True):
        if dry_run:
            print("=== 模拟创建 Jira 任务 ===")
            for v in violations:
                print(f"[Jira] 创建任务: {v['detail']} | 指派给: 开发负责人")
        else:
            # 实际对接 Jira REST API 的代码可写在这里
            pass

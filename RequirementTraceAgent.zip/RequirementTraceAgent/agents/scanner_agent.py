import os
import ast
from typing import List, Dict

class ScannerAgent:
    def scan(self, repo_path: str) -> List[Dict]:
        features = []
        for root, dirs, files in os.walk(repo_path):
            for file in files:
                if file.endswith(".py"):
                    filepath = os.path.join(root, file)
                    with open(filepath, "r", encoding="utf-8") as f:
                        content = f.read()
                    # 提取函数定义作为功能点
                    try:
                        tree = ast.parse(content)
                        for node in ast.walk(tree):
                            if isinstance(node, ast.FunctionDef):
                                features.append({
                                    "type": "function",
                                    "name": node.name,
                                    "file": filepath,
                                    "code": ast.unparse(node)[:200]  # 截取部分代码
                                })
                    except:
                        # 简单正则兜底
                        import re
                        funcs = re.findall(r'def (\w+)\s*\(', content)
                        for fname in funcs:
                            features.append({
                                "type": "function",
                                "name": fname,
                                "file": filepath,
                                "code": ""
                            })
        return features

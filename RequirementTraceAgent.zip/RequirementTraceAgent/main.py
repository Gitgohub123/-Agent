import json
import os
from agents.parser_agent import ParserAgent
from agents.scanner_agent import ScannerAgent
from agents.comparator_agent import ComparatorAgent
from agents.reporter_agent import ReporterAgent

def load_config():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def main():
    print("=== 需求追踪与合规检查 Agent 启动 ===")
    config = load_config()
    
    # 1. 解析需求文档
    parser = ParserAgent()
    requirements = parser.parse(config["requirement_file"])
    print(f"解析到 {len(requirements)} 条需求")
    
    # 2. 扫描代码仓库
    scanner = ScannerAgent()
    features = scanner.scan(config["code_repo_path"])
    print(f"扫描到 {len(features)} 个功能点 / API")
    
    # 3. 比对分析 (长链推理 + 多 Agent 协作)
    comparator = ComparatorAgent()
    coverage_result, compliance_violations = comparator.compare(requirements, features, config["compliance_rules"])
    
    # 4. 生成报告
    reporter = ReporterAgent()
    reporter.generate_report(coverage_result, compliance_violations, output_file="trace_report.md")
    reporter.create_jira_tasks(compliance_violations, dry_run=True)
    print("报告已生成: trace_report.md")

if __name__ == "__main__":
    main()

def backup_database():
    # 执行备份到本地 /data/backup/
    os.system("pg_dump > /data/backup/db.sql")
    # 注: 没有跨境传输，符合要求

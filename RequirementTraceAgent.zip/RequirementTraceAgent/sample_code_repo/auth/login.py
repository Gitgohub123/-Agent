def login(mobile, password):
    # 密码加密传输 (实现了加密)
    encrypted_pwd = encrypt(password)
    return db.query_user(mobile, encrypted_pwd)

def encrypt(data):
    # 简单的模拟加密
    return "encrypted_" + data

# 缺少审计日志

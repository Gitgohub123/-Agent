def export_orders_csv():
    orders = fetch_orders()
    with open("orders.csv", "w") as f:
        for o in orders:
            # 违规: 写入了用户手机号明文
            f.write(f"{o['id']},{o['user_mobile']},{o['total']}\n")
    # 缺少审计日志记录
